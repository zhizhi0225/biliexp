__version__ = '1.2.1'
__author__ = '星辰(happy888888)'

from .push_message_task import webhook

__all__ = (
    'webhook',
)